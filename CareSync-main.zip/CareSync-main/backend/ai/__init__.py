# CareSync AI module
